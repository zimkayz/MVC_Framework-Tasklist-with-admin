# MVC framework_TaskList
 This is a simple application to add a task and view it and update the task. This was done purely for test purposes requested by an employer to view my php skills.
