<?php
    
    define('DB_HOST', '127.0.0.1'); 
    define('DB_USER', 'akitonyz_zimkeiz'); 
    define('DB_PASS', 'Elijah1993');
    define('DB_NAME', 'akitonyz_zimkeiz'); 


   
    define('APPROOT', (dirname(dirname(__FILE__))));

   
    define('URLROOT', '');

    
    define('SITENAME', 'MVC Framework');

    


?>