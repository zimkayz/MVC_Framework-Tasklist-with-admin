
<?php require APPROOT . '/views/includes/header.php'?>

<?php require APPROOT . '/views/includes/head.php'?>
<?php if(isset($_SESSION['upload'])){?>


<div class="alert alert-success" class="alert-dismissible fade show" role="alert">
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      <?php
            echo $_SESSION['upload'];
            unset ($_SESSION['upload']);
      }?>
</div>

  


<div class="links">
    <ul class="list-group list-group-horizontal">
        <li class="list-group item">
        <a class="btn btn-primary" href=" <?php echo URLROOT; ?>/tasks/create" role="button">Add Task</a>
        </li><span style="padding-left: 10px;">
        <li class="list-group item">
            <?php if(isset($_SESSION['user_id'])) : ?>
               <a href="<?php echo URLROOT; ?>/users/logout"class="btn btn-outline-danger">Log out</a>
                  <?php else : ?>
               <a href="<?php echo URLROOT; ?>/users/login" class="btn btn-outline-success">Login</a>
                  <?php endif; ?>
          </li></span>
          
    </ul>
</div>
<hr style="color: white;">
<div id="List Table">
    <table class="col-md-12 table-sortable table-bordered table-primary table table-hover" id="list_table"  >
        <thead class="table-light">
        		<tr>
                <th scope="col">ID</th>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">task</th>
                <th scope="col">status</th>                        
        		</tr>
        </thead>
        		<tbody>
                <?php foreach($data['tasks'] as $task):?>
        			<tr>
        				  <td data-label="ID"><?php echo $task->id; ?></td>
        				  <td data-label="Username"><?php echo $task->user_name; ?></td>
                  <td data-label="Email"><?php echo $task->user_email; ?></td>
                  <td data-label="Task"><?php echo $task->user_task; ?>.</td>
                  <td data-label="status"><?php echo $task->user_status; ?></td>        
        			</tr>
                    <?php endforeach; ?>
        	  </tbody>
      </table>
</div>

<div class="clearfix"></div>
<hr style="color: white;">
<div class="row">
  <div class="col-4">
    <div class="list-group" id="list-tab" role="tablist">
      <a class="list-group-item list-group-item-action active" id="list-home-list" data-bs-toggle="list" href="#list-home" role="tab" aria-controls="list-home">Full Table</a>
      <a class="list-group-item list-group-item-action" id="list-profile-list" data-bs-toggle="list" href="#list-profile" role="tab" aria-controls="list-profile">Profile</a>
      <a class="list-group-item list-group-item-action" id="list-messages-list" data-bs-toggle="list" href="#list-messages" role="tab" aria-controls="list-messages">Links</a>
      <a class="list-group-item list-group-item-action" id="list-settings-list" data-bs-toggle="list" href="#list-settings" role="tab" aria-controls="list-settings">Skills</a>
    </div>
  </div>
  <div class="col-8">
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
      <div class="table_2">
             
        
          <div class="card card-body">
              <div id="List Table">
                  <table >
                    <thead>
                      <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Username</th>
                        <th scope="col">Email</th>
                        <th scope="col">task</th>
                        <th scope="col">status</th>         
                      </tr>
                    </thead>
                    <tbody>
                        <?php foreach($data['tasks'] as $task):?>
                      <tr>
                      <td data-label="ID"><?php echo $task->id; ?></td>
                      <td data-label="Username"><?php echo $task->user_name; ?></td>
                      <td data-label="Email"><?php echo $task->user_email; ?></td>
                      <td data-label="Task"><?php echo $task->user_task; ?>.</td>
                      <td data-label="status"><?php echo $task->user_status; ?></td>   
                              
                      </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
              </div>
         
        </div>
</div>

      </div>
      <div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">
      <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="https://scontent.fhel5-1.fna.fbcdn.net/v/t1.6435-9/107387983_2610732855692829_1685255529278914406_n.jpg?_nc_cat=100&ccb=1-5&_nc_sid=09cbfe&_nc_eui2=AeFBoNfLaaVEuO2AZuE_kpakAaX7YJSPay0BpftglI9rLTJuSzLYBOujbkayVPeGoS0_HjdZHZAU-4xoy64zbRbL&_nc_ohc=8ZpuXg9wK9kAX8tmQN0&_nc_ht=scontent.fhel5-1.fna&oh=36a3837e2cfb3c1c0c08f0001b444296&oe=618513A6" alt="Admin" class="rounded-circle" width="100">
                    <div class="mt-3">
                      <h4>Элидша Кутсива</h4>
                      <p class="text-secondary mb-1">Full Stack Developer</p>
                      <p class="text-muted font-size-sm">Санкт-Петербург Россия </p>
                     
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      Кутсива Элидша
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Email</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      kutsiwaelijah@gmail.com
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Phone</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      +7 911 153 43 84
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Mobile</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                     +7 921 589 33 20
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Address</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                    Санкт-Петербург Россия 
                    </div>
                  </div>
                  <hr>
                 
                </div>
              </div>

              



            </div>
          </div>
      </div>
      <div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list"><div class="card mt-3">
                <ul class="list-group list-group-flush">
                  <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                    <h6 class="mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-globe mr-2 icon-inline"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>Website</h6>
                    <a href="http://muzhalo.info/ekayz.ru/"><span class="text-secondary">http://muzhalo.info/ekayz.ru/</span></a>
                  </li>
                  <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                    <h6 class="mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-github mr-2 icon-inline"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>Github</h6>
                    <a href="https://github.com/zimkayz"><span class="text-secondary">https://github.com/zimkayz</span></a>
                  </li>
                  <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                    <h6 class="mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-instagram mr-2 icon-inline text-danger"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>Instagram</h6>
                    <a href="https://www.instagram.com/1st_chirandu/"><span class="text-secondary">https://www.instagram.com/1st_chirandu/</span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                    <h6 class="mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-facebook mr-2 icon-inline text-primary"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>Facebook</h6>
                    <a href="https://www.facebook.com/elijahkutsiwa"><span class="text-secondary">https://www.facebook.com/elijahkutsiwa</span></a>
                  </li>
                </ul>
              </div></div>
      <div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list"><div class="row gutters-sm">
                <div class="col-sm-6 mb-3">
                  <div class="card h-100">
                    <div class="card-body">
                      <h6 class="d-flex align-items-center mb-3"><i class="material-icons text-info mr-2">Currently</i>Skills Status</h6>
                      <small>Web Design</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Website Markup</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 72%" aria-valuenow="72" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>One Page</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 89%" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Mobile Template</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 55%" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Backend API</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 66%" aria-valuenow="66" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 mb-3">
                  <div class="card h-100">
                    <div class="card-body">
                      <h6 class="d-flex align-items-center mb-3"><i class="material-icons text-info mr-2">Currently</i>Frameworks & langauges</h6>
                      <small>Bootstrap</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Laravel</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 82%" aria-valuenow="72" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>MVC(PHP)</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 89%" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>OOP</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 55%" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <small>Javascript</small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 55%" aria-valuenow="66" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div></div>
    </div>
  </div>
</div>






          <?php require APPROOT . '/views/includes/footer.php'?>