<?php require APPROOT . '/views/includes/header.php'?>


<div class="container">
    <div class="row g-3">   
        <h1>Create a new Task</h1>
            <form action="<?php echo URLROOT;?>/tasks/create" method="POST">
                <div class="col-md-6">
                    <div class ="input-group">
                        <span class="input-group-text" id="username">Username</span>
                             <input type="text" class="form-control" name="user_name" >   
                    </div>
                    <div class="invalidFeedback">
                        <?php echo $data['user_name_error'];?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class ="input-group">
                        <span class="input-group-text" id="Email">Email</span>
                             <input type="email" class="form-control" name="user_email" required=""  oninvalid="this.setCustomValidity('Please Enter valid email')"
                                 oninput="setCustomValidity('')" >     
                    </div>
                    <div class="invalidFeedback">
                        <?php echo $data['user_email_error'];?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class ="input-group">
                         <span class="input-group-text" id="Task">Task</span>
                            <input class="form-control" type="text" name="user_task" >
                    </div>
                    <div class="invalidFeedback">
                        <?php echo $data['user_task_error'];?>
                    </div>
                </div>
        
                <div class="hidden inputs">
                   <input type="text" class="form-control" name="user_status" hidden value="-" >
                   <input type="text" class="form-control" name="edited" hidden value="-" >
                </div>
                   
                <button class="btn btn-success" name="submit" type="submit">Submit</button>
            </form>
    </div>
</div>

    


<?php require APPROOT . '/views/includes/footer.php'?>