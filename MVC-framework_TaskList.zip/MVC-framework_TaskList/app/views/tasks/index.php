<?php if(isLoggedIn()): ?><?php 
require APPROOT . '/views/includes/header.php'?>

<?php if(isset($_SESSION['updated'])){?>

<div class="alert alert-success" class="alert-dismissible fade show" role="alert">
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php
        echo $_SESSION['updated'];
        unset ($_SESSION['updated']);
        }
      ?>
</div>

<div class="links">
    <a href="<?php echo URLROOT; ?>/users/logout" class="btn btn-outline-danger">Logout</a>
</div>

<div id="List Table">
    <table class="col-md-12 table-sortable table-bordered table-success table table-hover" id="list_table">
        <thead class="table-light">
        			<tr>
                    <th scope="col">ID</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">task</th>
                    <th scope="col">status Updated?</th>     
                        <th scope="col">Edit</th>
                        <th scope="col">Update</th>                       
        			</tr>
        </thead>
        <tbody>
                <?php foreach($data['tasks'] as $task):?>
        			<tr>
        				<td data-label="ID"><?php echo $task->id; ?></td>
        				<td data-label="Username"><?php echo $task->user_name; ?></td>
                        <td data-label="Email"><?php echo $task->user_email; ?></td>
                        <td data-label="Task"><?php echo $task->user_task; ?>.</td>
                        <td data-label="status"><?php echo $task->user_status; ?></td>
                        <td data-label="edited"><?php echo $task->edited; ?></td>
                        <td data-label="update">
                            <?php if(isset($_SESSION['user_id'])&& $_SESSION['user_id']== 4): ?>
                            <a class ="btn btn-outline-info" href="<?php echo URLROOT . "/tasks/update/" . $task->id?>">Update</a>
                            <?php endif; ?> 
                        </td>       
        			</tr>
                    <?php endforeach; ?>
        </tbody>
    </table>
</div>






<?php require APPROOT . '/views/includes/footer.php'?>
<?php endif;?>
<?php if(!isLoggedIn()): ?>
<?php { header('location:' . URLROOT . '/index'); exit;}?>
<?php endif;?>
