<?php require APPROOT . '/views/includes/header.php'?>


<div class container>
    <div class="row g-3">
    <h1>Update Task</h1>
    <form action="<?php echo URLROOT;?>/tasks/update/<?php echo $data['task']->id ?>" method="POST">
        <div class="col-md-6">
               <div class ="input-group">
               <span class="input-group-text" id="username">Username</span>
                   <input type="text" class="form-control" name="user_name" value="<?php echo $data['task']->user_name ?> ">
                   <span class ="invalidFeedback" ><?php echo $data['user_name_error'];?></span>
               </div>
        </div>
        <div class="col-md-6">
               <div class ="input-group">
               <span class="input-group-text" id="Email">Email</span>
                   <input type="text" class="form-control" name="user_email"  value="<?php echo $data['task']->user_email ?> ">
                   <span class ="invalidFeedback"><?php echo $data['user_email_error'];?></span>
               </div>
        </div>
        <div class="col-md-6">
               <div class ="input-group">
               <span class="input-group-text" id="Task">Task</span>
                  <textarea class="form-control" name="user_task" aria-label="With textarea"><?php echo $data['task']->user_task ?></textarea>
                  <span class ="invalidFeedback"><?php echo $data['user_task_error'];?></span>
               </div>
        </div>
        <div class="col-md-6">
               <div class ="input-group">
               <span class="input-group-text" id="Email">Status</span>
                  
                   <select class="form-select" id="status choice" name="user_status">
                        <option selected>Choose...</option>
                        <option value="In Progress">InProgress</option>
                        <option value="Completed">Completed</option>
                    </select>
               </div>
        </div>
        <input hidden name="edited" value="edited by Admin">
        <button class="btn btn-success" name="submit" type="submit">Submit</button>
     </form>
        </div>
    </div>


<?php require APPROOT . '/views/includes/footer.php'?>