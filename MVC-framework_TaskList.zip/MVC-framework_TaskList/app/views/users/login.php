<?php require APPROOT . '/views/includes/header.php'?>
   <div class="login-box">
    <form action="<?php echo URLROOT; ?>/users/login" method="POST">
        <h2 class="text-center">Log in</h2>       
        <div class="user-box">
            
            <input type="text" name="username"  >
            <span class="invalidFeedback"><?php echo $data['usernameError']; ?></span>
            <label>Username</label>
        </div>
        <div class="user-box">
            
            <input type="password" name="password">
            <span class="invalidFeedback"><?php echo $data['passwordError']; ?></span>
            <label>Password</label>
        </div>
        
            <a>  <span></span>
      <span></span>
      <span></span>
      <span></span>
      <button type="submit" id="submit" class="btn btn-light" value="submit" >Log in</button></a>
        
        <div class="clearfix">
            <div class="login">
            <label class="float-left"> Log In Details</label><br>
            <label class="float-left">Username:admin</label><br>
            <label class="float-left"> Password 123</label><br>
            <a href="<?php echo URLROOT; ?>/index" class="float-right">Back to Task List</a>  
        </div>  
        </div>      
    </form>
   
</div>






<?php require APPROOT . '/views/includes/footer.php'?>